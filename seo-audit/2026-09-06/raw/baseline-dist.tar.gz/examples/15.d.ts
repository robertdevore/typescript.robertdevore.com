type Verb = "queued" | "finished";
export type EventName = `job:${Verb}`;
export {};
