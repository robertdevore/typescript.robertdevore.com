import assert from "node:assert/strict";
function get(value, key) {
    return value[key];
}
const count = get({ count: 2 }, "count");
assert.equal(count, 2);
console.log("runtime and type contract passed");
export {};
//# sourceMappingURL=23.js.map