function emit(name, payload) {
    console.log(name, payload.id);
}
emit("job:finished", { id: "j1", durationMs: 12 });
export {};
//# sourceMappingURL=15.js.map