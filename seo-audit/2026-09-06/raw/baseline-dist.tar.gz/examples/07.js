function parse(value) {
    return Number.isInteger(value) && value >= 0
        ? { ok: true, count: value }
        : { ok: false, code: "invalid_count" };
}
function retries(value) {
    return value ?? 3;
}
console.log(retries(0));
const result = parse(-1);
console.log(result.ok ? result.count : result.code);
export {};
//# sourceMappingURL=07.js.map