export function normalizeLimit(value) {
    if (!Number.isInteger(value) || value < 1)
        throw new Error("Invalid limit");
    return value;
}
console.log(normalizeLimit(2));
export {};
//# sourceMappingURL=31.js.map