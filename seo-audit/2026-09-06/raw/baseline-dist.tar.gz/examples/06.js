function summarize(job) {
    return `${job.id}: ${job.label}`;
}
const job = { id: "j1", label: "Import", owner: "internal" };
const outcome = { ok: true, job };
if (outcome.ok)
    console.log(summarize(outcome.job));
console.log(Object.keys(job).join(","));
export {};
//# sourceMappingURL=06.js.map