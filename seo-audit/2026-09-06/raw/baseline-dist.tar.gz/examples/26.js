function read(summary, key) {
    return key === undefined ? summary : summary[key];
}
export const count = read({ total: 4, failed: 1 }, "total");
console.log(count);
export {};
//# sourceMappingURL=26.js.map