export declare function describeJob(id: string): string;
export {};
