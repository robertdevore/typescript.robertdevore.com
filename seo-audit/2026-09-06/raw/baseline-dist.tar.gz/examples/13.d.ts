type Job = {
    readonly id: string;
    label: string;
    attempts: number;
};
export {};
export type Getters<T> = {
    [K in keyof T as `get${Capitalize<string & K>}`]: () => T[K];
};
export type JobGetters = Getters<Job>;
