function get(value, key) {
    return value[key];
}
const job = { id: "j1", attempts: 2 };
export const attempts = get(job, "attempts");
export const phases = ["queued", "running", "done"];
console.log(attempts, get(job, "id"));
export {};
//# sourceMappingURL=12.js.map