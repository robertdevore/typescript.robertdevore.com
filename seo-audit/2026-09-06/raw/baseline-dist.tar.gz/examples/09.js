function label(value) {
    return typeof value === "string" ? value.toUpperCase() : "invalid";
}
const entries = [];
const record = (value) => entries.push(value);
function fail(message) {
    throw new Error(message);
}
record(label("ready"));
console.log(entries.join(","));
try {
    fail("stop");
}
catch (error) {
    console.log(error instanceof Error ? error.message : "unknown error");
}
export {};
//# sourceMappingURL=09.js.map