export declare const limits: {
    small: number;
    large: number;
};
export declare const routes: readonly ["jobs", "health"];
export {};
