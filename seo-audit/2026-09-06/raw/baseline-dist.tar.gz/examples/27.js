export function parseLabel(value) {
    return typeof value === "string" && value.trim() !== ""
        ? { ok: true, value: value.trim() }
        : { ok: false, reason: "Expected nonempty label" };
}
console.log(JSON.stringify(parseLabel(" Import ")));
export {};
//# sourceMappingURL=27.js.map