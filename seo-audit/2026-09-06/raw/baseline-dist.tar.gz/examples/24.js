async function save() {
    return "saved";
}
await save()
    .then((message) => console.log(message))
    .catch((error) => {
    console.error(error instanceof Error ? error.message : "save failed");
    process.exitCode = 1;
});
export {};
//# sourceMappingURL=24.js.map