export declare function summarize(values: readonly number[]): {
    total: number;
};
export {};
