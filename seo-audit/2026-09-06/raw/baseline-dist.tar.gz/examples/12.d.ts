export declare const attempts: number;
export declare const phases: readonly ["queued", "running", "done"];
export type Phase = (typeof phases)[number];
export {};
