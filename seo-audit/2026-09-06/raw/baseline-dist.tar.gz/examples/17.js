const consume = (job) => console.log(job.id);
const ownedConsumer = consume;
ownedConsumer({ id: "j1", owner: "Ada" });
const produce = () => ({ id: "j2", owner: "Lin" });
const generalProducer = produce;
console.log(generalProducer().id);
export {};
//# sourceMappingURL=17.js.map