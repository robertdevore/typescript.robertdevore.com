export function parseJobId(value) {
    if (typeof value !== "string" || !/^job_[a-z0-9]+$/.test(value))
        throw new Error("Invalid job ID");
    // The runtime regex establishes the invariant; TypeScript cannot infer a brand from it.
    return value;
}
console.log(parseJobId("job_abc"));
export {};
//# sourceMappingURL=32.js.map