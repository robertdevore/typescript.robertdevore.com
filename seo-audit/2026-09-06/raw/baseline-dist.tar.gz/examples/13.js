function update(job, patch) {
    return { ...job, ...patch };
}
const job = { id: "j1", label: "Import", attempts: 0 };
console.log(update(job, { attempts: 2 }).attempts);
export {};
//# sourceMappingURL=13.js.map