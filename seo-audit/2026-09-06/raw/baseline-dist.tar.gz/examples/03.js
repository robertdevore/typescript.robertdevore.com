function makeFormatter(prefix, separator = ": ") {
    let calls = 0;
    return (...parts) => {
        calls += 1;
        return `${prefix}${separator}${parts.join(" ")} (#${calls})`;
    };
}
const format = makeFormatter("job");
console.log(format("ready"));
console.log(format("done", "today"));
export {};
//# sourceMappingURL=03.js.map