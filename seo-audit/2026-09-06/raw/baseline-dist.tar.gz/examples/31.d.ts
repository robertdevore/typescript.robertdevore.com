export declare function normalizeLimit(value: number): number;
export {};
