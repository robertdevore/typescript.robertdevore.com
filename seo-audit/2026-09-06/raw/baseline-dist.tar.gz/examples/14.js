console.log(["job", 2].join(": "));
export {};
//# sourceMappingURL=14.js.map