export const limits = { small: 2, large: 8 };
export const routes = ["jobs", "health"];
console.log(limits.small, routes[0]);
export {};
//# sourceMappingURL=10.js.map