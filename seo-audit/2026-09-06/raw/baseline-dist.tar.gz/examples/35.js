export function describeJob(id) {
    return `Job ${id}`;
}
console.log(describeJob("j1"));
export {};
//# sourceMappingURL=35.js.map