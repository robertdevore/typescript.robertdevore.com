const source = { attempts: 0 };
const view = source;
source.attempts = 3;
console.log(view.attempts);
export function requireButton(root) {
    const element = root.querySelector("#run");
    if (!(element instanceof HTMLButtonElement))
        throw new Error("Expected run button");
    return element;
}
export {};
//# sourceMappingURL=33.js.map