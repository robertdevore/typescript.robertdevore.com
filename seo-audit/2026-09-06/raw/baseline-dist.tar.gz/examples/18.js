const counts = { queued: 2 };
const running = counts["running"] ?? 0;
console.log(running);
export {};
//# sourceMappingURL=18.js.map