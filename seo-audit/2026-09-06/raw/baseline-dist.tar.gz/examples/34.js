async function describe(reader, id) {
    const job = await reader.find(id);
    return job ? `${job.id}: ${job.label}` : "not found";
}
const memory = {
    async find(id) {
        return id === "j1" ? { id, label: "Import" } : undefined;
    },
};
console.log(await describe(memory, "j1"));
export {};
//# sourceMappingURL=34.js.map