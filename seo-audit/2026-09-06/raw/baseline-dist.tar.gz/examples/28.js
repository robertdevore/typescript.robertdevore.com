export function summarize(values) {
    return { total: values.reduce((sum, value) => sum + value, 0) };
}
console.log(JSON.stringify(summarize([2, 3])));
export {};
//# sourceMappingURL=28.js.map