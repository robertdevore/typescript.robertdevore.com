export declare let name: string;
export declare const status = "ready";
export declare const config: {
    status: string;
};
export {};
