import { basename } from "node:path";
console.log(basename("/jobs/import.json"));
export {};
//# sourceMappingURL=19.js.map