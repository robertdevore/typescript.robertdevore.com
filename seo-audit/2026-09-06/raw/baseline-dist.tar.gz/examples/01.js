function greet(name) {
    return `Welcome, ${name}!`;
}
console.log(greet("developer"));
export {};
//# sourceMappingURL=01.js.map