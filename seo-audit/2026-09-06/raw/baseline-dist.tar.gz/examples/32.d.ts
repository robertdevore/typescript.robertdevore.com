declare const jobIdBrand: unique symbol;
export type JobId = string & {
    readonly [jobIdBrand]: true;
};
export declare function parseJobId(value: unknown): JobId;
export {};
