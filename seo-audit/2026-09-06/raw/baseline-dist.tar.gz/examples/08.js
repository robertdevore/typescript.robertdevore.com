function identify(value) {
    return value.id;
}
const job = { id: "j1", internal: true };
console.log(identify(job));
console.log(JSON.stringify(job));
export {};
//# sourceMappingURL=08.js.map