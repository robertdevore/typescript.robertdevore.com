export declare const wrapped: {
    value: {
        id: string;
        attempts: number;
    };
};
export declare const counts: number[];
export {};
