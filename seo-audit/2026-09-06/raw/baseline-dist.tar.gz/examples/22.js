async function readId(transport, signal) {
    const response = await transport("https://example.invalid/jobs/j1", { signal });
    if (!response.ok)
        throw new Error(`HTTP ${response.status}`);
    const value = await response.json();
    if (typeof value !== "object" ||
        value === null ||
        !("id" in value) ||
        typeof value.id !== "string")
        throw new Error("Invalid payload");
    return value.id;
}
const fixture = async () => Response.json({ id: "j1" });
console.log(await readId(fixture, new AbortController().signal));
export {};
//# sourceMappingURL=22.js.map