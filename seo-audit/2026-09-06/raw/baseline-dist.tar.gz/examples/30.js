function summarize(jobs) {
    return { total: jobs.length, attempts: jobs.reduce((sum, job) => sum + job.attempts, 0) };
}
console.log(JSON.stringify(summarize([{ attempts: 2 }])));
export {};
//# sourceMappingURL=30.js.map