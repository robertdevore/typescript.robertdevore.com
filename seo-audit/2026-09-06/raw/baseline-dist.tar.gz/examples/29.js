const memory = {
    async find(id) {
        return id === "j1" ? "Import" : undefined;
    },
};
console.log(await memory.find("j1"));
export {};
//# sourceMappingURL=29.js.map