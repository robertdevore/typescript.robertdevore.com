const job = { id: "j1", meta: { attempts: 0 } };
const copy = { ...job };
copy.meta.attempts += 1;
const summary = [job.id, job.meta.attempts];
console.log(summary.join(": "));
export {};
//# sourceMappingURL=04.js.map