export type ParsedLabel = {
    ok: true;
    value: string;
} | {
    ok: false;
    reason: string;
};
export declare function parseLabel(value: unknown): ParsedLabel;
export {};
