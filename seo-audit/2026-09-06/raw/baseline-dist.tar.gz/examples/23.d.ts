type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends <T>() => (T extends B ? 1 : 2) ? true : false;
type Expect<T extends true> = T;
declare const count: number;
export type Check = Expect<Equal<typeof count, number>>;
export {};
