export declare function requireButton(root: Document): HTMLButtonElement;
export {};
